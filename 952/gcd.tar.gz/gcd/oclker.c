/* OpenCL kernel definition */

#define LOCALSTEPS		1024

/* compute the GCD of a and b; a local function called by the kernel */
static long gcdnum(long a, long b)
{
	while (b > 0) {
		int t = a;
		a = b;
		b = t % b;
	}
	return a;
}

/* GCD kernel: decide if the assigned number is prime */
__kernel void gcd(int cnt, __global long *nums, __global char *prms)
{
	int gid = get_group_id(0);		/* work group ID */
	int lid = get_local_id(0);		/* work item ID in this work group */
	int id = gid * get_local_size(0) + lid;	/* the global ID of this work item */
	int i, j;
	/* the basic algorithm; not using local memory */
	//if (id < cnt) {
	//	int n = 0;
	//	int num = nums[id];
	//	for (i = 0; i < cnt; i++)
	//		if (gcdnum(num, nums[i]) > 1)
	//			n++;
	//	prms[id] = n == 1;
	//}
	/* the basic algorithm; using local memory */
	if (id < cnt) {
		/* local memory is limited; dividing the numbers into groups of size LOCALSTEPS */
		__local long lnums[LOCALSTEPS];
		for (i = 0; i < cnt; i += LOCALSTEPS) {
			int num = nums[id];
			prms[id] = 1;
			/* copying the numbers to local memory */
			for (j = lid; j < LOCALSTEPS; j += get_local_size(0))
				lnums[j] = nums[i + j];
			barrier(CLK_LOCAL_MEM_FENCE);		/* synchronizing work items */
			for (j = 0; j < LOCALSTEPS; j++) {
				if (i + j != id && gcdnum(num, lnums[j]) > 1) {
					prms[id] = 0;
					break;
				}
			}
			barrier(CLK_LOCAL_MEM_FENCE);		/* synchronizing work items */
		}
	}
}
