/* Example OpenCL Program (Parallel Processing - Spring 1396) */
#include <stdio.h>
#include <stdlib.h>
#include <CL/cl.h>

#define NDEV		8		/* the number of devices to store */
#define NPLT		8		/* the number of platforms to store */
#define KERNPATH	"oclker.c"	/* kernel source path */
#define KERNNAME	"gcd"		/* kernel name */
#define MAXITEMS	8192		/* the maximum number of work items per work group */

/* read the kernel source */
static char *oclkern(char *path)
{
	FILE *fp = fopen(path, "r");
	char *dst;
	int len = 0;
	int sz = 1 << 12;
	int nr;
	if (!fp)
		return NULL;
	dst = malloc(sz * sizeof(dst[0]));
	while ((nr = fread(dst + len, 1, sz - len, fp)) > 0)
		len += nr;
	fclose(fp);
	dst[len] = '\0';
	return dst;
}

int main(int argc, char **argv)
{
	long *nums;		/* input numbers */
	char *prms;		/* indicate if any of the input numbers are prime */
	int cnt;		/* the number of input numbers */
	cl_mem nums_dev;	/* pointer to nums in device global memory */
	cl_mem prms_dev;	/* pointer to prms in device global memory */
	cl_platform_id platforms[NPLT];
	cl_platform_id platform;
	cl_uint platforms_cnt;
	cl_uint devs_cnt;
	cl_device_id devs[NDEV];
	cl_device_id dev;
	cl_context ctx;
	cl_command_queue cmd;
	cl_program prog;
	cl_kernel kern;
	size_t local;		/* the number of work items in each work group */
	size_t global;		/* total number of work items */
	char *src;		/* kernel source */
	int pltidx = 0;		/* selected OpenCL platform */
	int devidx = 0;		/* selected OpenCL device */
	char name[128];
	int err;
	int i;
	size_t len;
	for (i = 1; i < argc; i++) {
		if (argv[i][0] != '-' || !argv[i][1])
			break;
		if (argv[i][1] == 'p')
			pltidx = atoi(argv[i][2] ? argv[i] + 2 : argv[++i]);
		if (argv[i][1] == 'd')
			devidx = atoi(argv[i][2] ? argv[i] + 2 : argv[++i]);
	}
	err = clGetPlatformIDs(NPLT, platforms, &platforms_cnt);
	if (err != CL_SUCCESS) {
		printf("ocl: no platform!\n");
		return 1;
	}
	if (pltidx < 0) {
		printf("Platforms:\n");
		for (i = 0; i < platforms_cnt; i++) {
			clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, sizeof(name), name, &len);
			if (err == CL_SUCCESS)
				printf("\t%d: %s\n", i, name);
		}
		return 1;
	}
	if (pltidx >= platforms_cnt) {
		printf("ocl: no such platform!\n");
		return 1;
	}
	platform = platforms[pltidx];
	err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_ALL, NDEV, devs, &devs_cnt);
	if (devidx < 0) {
		for (i = 0; i < devs_cnt; i++) {
			err = clGetDeviceInfo(devs[i], CL_DEVICE_NAME, sizeof(name), name, &len);
			if (err == CL_SUCCESS)
				printf("\t%d: %s\n", i, name);
		}
		return 1;
	}
	if (devidx >= devs_cnt) {
		printf("ocl: no such device!\n");
		return 1;
	}
	dev = devs[devidx];
	ctx = clCreateContext(NULL, 1, &dev, NULL, NULL, &err);
	if (!ctx) {
		printf("ocl: failed to create a context!\n");
		return 1;
	}
	cmd = clCreateCommandQueue(ctx, dev, 0, &err);
	if (!cmd) {
		printf("ocl: failed to create a command queue!\n");
		return 1;
	}
	src = oclkern(KERNPATH);
	prog = clCreateProgramWithSource(ctx, 1, (void *) &src, NULL, &err);
	if (!prog) {
		printf("ocl: failed to create program!\n");
		return 1;
	}
	err = clBuildProgram(prog, 0, NULL, NULL, NULL, NULL);
	if (err != CL_SUCCESS) {
		char msg[2048];
		clGetProgramBuildInfo(prog, dev, CL_PROGRAM_BUILD_LOG, sizeof(msg), msg, &len);
		printf("ocl: program failed to build!\n");
		printf("%s\n", msg);
		return 1;
	}
	kern = clCreateKernel(prog, KERNNAME, &err);
	if (!kern) {
		printf("ocl: failed to create the kernel!\n");
		return 1;
	}
	/* reading the inputs */
	scanf("%d", &cnt);
	nums = malloc(cnt * sizeof(nums[0]));
	prms = malloc(cnt * sizeof(prms[0]));
	for (i = 0; i < cnt; i++)
		if (scanf("%ld", &nums[i]) != 1)
			fprintf(stderr, "bad input");
	nums_dev = clCreateBuffer(ctx, CL_MEM_WRITE_ONLY, cnt * sizeof(nums[0]), NULL, NULL);
	prms_dev = clCreateBuffer(ctx, CL_MEM_READ_ONLY, cnt * sizeof(prms[0]), NULL, NULL);
	if (!nums_dev || !prms_dev) {
		printf("ocl: cannot allocate memory!\n");
		return 1;
	}    
	clEnqueueWriteBuffer(cmd, nums_dev, CL_TRUE, 0, cnt * sizeof(nums[0]), nums, 0, NULL, NULL);
	clSetKernelArg(kern, 0, sizeof(cnt), &cnt);
	clSetKernelArg(kern, 1, sizeof(nums_dev), &nums_dev);
	clSetKernelArg(kern, 2, sizeof(prms_dev), &prms_dev);
	/* obtaining maximum work group size supported by the device */
	err = clGetKernelWorkGroupInfo(kern, dev, CL_KERNEL_WORK_GROUP_SIZE, sizeof(local), &local, NULL);
	if (err != CL_SUCCESS) {
		printf("ocl: failed to query work group size!");
		return 1;
	}
	if (local > MAXITEMS)
		local = MAXITEMS;
	global = cnt;			/* the total number of threads */
	err = clEnqueueNDRangeKernel(cmd, kern, 1, NULL, &global, &local, 0, NULL, NULL);
	if (err) {
		printf("ocl: failed to execute the kernel!\n");
		return 1;
	}
	clFinish(cmd);
	err = clEnqueueReadBuffer(cmd, prms_dev, CL_TRUE, 0, sizeof(prms[0]) * cnt, prms, 0, NULL, NULL);
	if (err != CL_SUCCESS) {
		printf("ocl: failed to read the results!\n");
		return 1;
	}
	for (i = 0; i < cnt; i++)	/* printing the results */
		if (prms[i])
			printf("%ld\n", nums[i]);
	free(prms);
	free(nums);
	free(src);
	clReleaseMemObject(nums_dev);
	clReleaseMemObject(prms_dev);
	clReleaseProgram(prog);
	clReleaseKernel(kern);
	clReleaseCommandQueue(cmd);
	clReleaseContext(ctx);
	return 0;
}
