# !/bin/sh
echo    "Threads	AVX	Time(s)"
echo -n "1	0	"
./mul 1
echo -n "2	0	"
./mul 2
echo -n "4	0	"
./mul 4

echo -n "1	1	"
./mul 1a
echo -n "2	1	"
./mul 2a
echo -n "4	1	"
./mul 4a
