/* AVX Intrinsics and PThreads for simple matrix multiplication */
#include <x86intrin.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#define NTHREADS		128
#define ALIGNMENT		512
#define M(m, i, j)		((m)->M + (m)->n2 * i + j)

/* n1 by n2 matrices */
struct mat {
	void *mem;		/* allocated memory */
	float *M;		/* aligned matrix content */
	int n1, n2;		/* matrix dimensions */
};

/* allocate and return a matrix with the given dimensions */
static struct mat *mat_make(int n1, int n2)
{
	struct mat *m = malloc(sizeof(*m));
	m->mem = malloc(n1 * n2 * sizeof(m->M[0]) + ALIGNMENT);
	/* aligning the matrix; required for AVX */
	m->M = (void *) ((((unsigned long) m->mem) + ALIGNMENT - 1) & ~(ALIGNMENT - 1));
	m->n1 = n1;
	m->n2 = n2;
	return m;
}

/* free a matrix struct */
static void mat_free(struct mat *m)
{
	free(m->mem);
	free(m);
}

/* initialize all entries of the given matrix to the given value */
static void mat_broadcast(struct mat *m, float val)
{
	int i, j;
	for (i = 0; i < m->n1; i++)
		for (j = 0; j < m->n2; j++)
			*M(m, i, j) = val;
}

/* calculate the i-th row of the multiplication of m1 and m2 */
static void mat_mul1(struct mat *r, struct mat *m1, struct mat *m2, int i)
{
	int j, k;
	for (j = 0; j < r->n2; j++) {
		float sum = 0;
		for (k = 0; k < r->n2; k++)
			sum += *M(m1, i, k) * *M(m2, j, k);
		*M(r, i, j) = sum;
	}
}

/* like mat_mul1(), but uses AVX intrinsics */
static void mat_mul1_avx(struct mat *r, struct mat *m1, struct mat *m2, int i)
{
	int j, k;
	for (j = 0; j < r->n2; j++) {
		__m256 sum8 = {0.0};
		for (k = 0; k < r->n2; k += 8) {
			__m256 a8 = _mm256_load_ps(M(m1, i, k));
			__m256 b8 = _mm256_load_ps(M(m2, j, k));
			sum8 = _mm256_add_ps(sum8, _mm256_mul_ps(a8, b8));
		}
		*M(r, i, j) = sum8[0] + sum8[1] + sum8[2] + sum8[3] +
			sum8[4] + sum8[5] + sum8[6] + sum8[7];
	}
}

/* multiply m1 and m2 and store the result in r; m1 and r are row-major and m2 is column-major */
static void mat_mul(struct mat *r, struct mat *m1, struct mat *m2)
{
	int i;
	for (i = 0; i < r->n1; i++)
		mat_mul1(r, m1, m2, i);
}

/* similar to mat_mul; uses AVX intrinsicts */
static void mat_mul_avx(struct mat *r, struct mat *m1, struct mat *m2)
{
	int i;
	for (i = 0; i < r->n1; i++)
		mat_mul1_avx(r, m1, m2, i);
}

/* current time stamp in milliseconds */
static long timestamp_ms(void)
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

/* partial multiplication data */
struct muldat {
	struct mat *r;
	struct mat *m1;
	struct mat *m2;
	int beg;
	int end;
	int avx;
};

/* partition the multiplication of matrices m1 and m2 into cnt tasks */
static struct muldat *muldat_make(struct mat *r, struct mat *m1, struct mat *m2, int cnt, int avx)
{
	struct muldat *md = malloc(cnt * sizeof(md[0]));
	int part = r->n1 / cnt;
	int i;
	for (i = 0; i < cnt; i++) {
		md[i].r = r;
		md[i].m1 = m1;
		md[i].m2 = m2;
		md[i].avx = avx;
		md[i].beg = i * part;
		md[i].end = i + 1 < cnt ? md[i].beg + part : r->n1;
	}
	return md;
}

/* perform partial matrix multiplication */
static void *threaded_mul(void *dat)
{
	struct muldat *md = dat;
	int i;
	for (i = md->beg; i < md->end; i++) {
		if (md->avx)
			mat_mul1_avx(md->r, md->m1, md->m2, i);
		else
			mat_mul1(md->r, md->m1, md->m2, i);
	}
	return NULL;
}

int main(int argc, char *argv[])
{
	struct mat *m1, *m2, *res;
	long beg, end;
	int n1 = 1 << 10;
	int n2 = 1 << 11;
	int cnt, avx;
	int i;
	if (argc < 2) {
		printf("Usage: %s mode\n\n", argv[0]);
		printf("Supported modes:\n");
		printf("  N  \t  use N threads without AVX\n");
		printf("  Na \t  use N threads with AVX\n");
		return 1;
	}
	cnt = atoi(argv[1]);
	if (cnt > NTHREADS)
		cnt = NTHREADS;
	avx = strchr(argv[1], 'a') != NULL;
	/* initializin the matrices */
	m1 = mat_make(n1, n2);
	m2 = mat_make(n2, n1);
	res = mat_make(n1, n2);
	mat_broadcast(m1, 1);
	mat_broadcast(m2, 1);
	/* multiplication modes */
	beg = timestamp_ms();
	if (cnt == 0) {
		if (avx)
			mat_mul_avx(res, m1, m2);
		else
			mat_mul(res, m1, m2);
	} else {
		struct muldat *md = muldat_make(res, m1, m2, cnt, avx);
		pthread_t threads[NTHREADS];
		for (i = 0; i < cnt; i++)
			pthread_create(&threads[i], NULL, threaded_mul, &md[i]);
		for (i = 0; i < cnt; i++)
			pthread_join(threads[i], NULL);
		free(md);
	}
	end = timestamp_ms();
	printf("%ld.%03ld\n", (end - beg) / 1000, (end - beg) % 1000);
	mat_free(m1);
	mat_free(m2);
	mat_free(res);
	return 0;
}
